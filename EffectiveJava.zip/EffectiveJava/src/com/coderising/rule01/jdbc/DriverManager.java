package com.coderising.rule01.jdbc;


import java.util.ArrayList;
import java.util.List;

public class DriverManager {
	
	private static final List<Driver> drivers = new ArrayList<>();
	
	public static void registerDriver(Driver driver){
		drivers.add(driver);
	}
	
	public static Connection getConnection(String url,String userName,String password){
		
		for(Driver aDriver: drivers){
			Connection conn = aDriver.getConnection(url, userName, password);
			if(conn != null){
				return conn;
			}
		}
		return null;
	}
	
}
