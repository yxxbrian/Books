package com.coderising.rule01.jdbc;

public interface Connection {
}
