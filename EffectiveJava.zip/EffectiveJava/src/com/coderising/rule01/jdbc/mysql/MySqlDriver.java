package com.coderising.rule01.jdbc.mysql;

import com.coderising.rule01.jdbc.Connection;
import com.coderising.rule01.jdbc.Driver;
import com.coderising.rule01.jdbc.DriverManager;

public class MySqlDriver implements Driver {
	static{
		DriverManager.registerDriver(new MySqlDriver());
	}
	@Override
	public Connection getConnection(String url, String userName, String password) {		
		if(url.contains("mysql")){
			return new MysqlConnection();
		}
		return null;
		
	}

}
