package com.coderising.rule01.jdbc.mysql;

import com.coderising.rule01.jdbc.Connection;

public class MysqlConnection implements Connection {
	public String toString(){
		return "this is a mysql connection"; 
	}
}
