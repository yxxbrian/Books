package com.coderising.rule01.jdbc.oracle;



import com.coderising.rule01.jdbc.Connection;
import com.coderising.rule01.jdbc.Driver;
import com.coderising.rule01.jdbc.DriverManager;

public class OracleDriver implements Driver {
	static{
		DriverManager.registerDriver(new OracleDriver());
	}
	@Override
	public Connection getConnection(String url, String userName, String password) {
		if(url.contains("oracle")){
			return new OracleConnection();
		}
		return null;
	}

}
