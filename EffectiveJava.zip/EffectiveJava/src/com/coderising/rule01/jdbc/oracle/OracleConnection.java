package com.coderising.rule01.jdbc.oracle;

import com.coderising.rule01.jdbc.Connection;

public class OracleConnection implements Connection {

}
