package com.coderising.rule01.jdbc;

public interface Driver {
	public Connection getConnection(String url,String userName,String password);
}
