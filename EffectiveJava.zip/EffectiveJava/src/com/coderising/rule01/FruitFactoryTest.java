package com.coderising.rule01;

import com.coderising.rule01.api.Fruit;
import com.coderising.rule01.api.FruitFactory;

public class FruitFactoryTest {

	public static void main(String[] args) {
		Fruit f1 = FruitFactory.create(1);
		
		
	}

}
