package com.coderising.rule01.api;

public class FruitFactory {
	public static Fruit create(int type){
		if(type == 1){
			return new AppleV2();
		}
		if (type == 2){
			return new Orange();
		}
		return null;
	}
}
