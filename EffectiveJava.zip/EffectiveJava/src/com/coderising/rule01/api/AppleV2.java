package com.coderising.rule01.api;

class AppleV2 implements Fruit {

}
