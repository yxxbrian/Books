package com.coderising.rule01.api;

class Orange implements Fruit {

}
