package com.coderising.rule01.api;

public interface Fruit {

}
