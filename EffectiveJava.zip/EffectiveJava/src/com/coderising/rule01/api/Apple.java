package com.coderising.rule01.api;

class Apple implements Fruit {

}
