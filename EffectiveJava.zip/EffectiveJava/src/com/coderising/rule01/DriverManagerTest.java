package com.coderising.rule01;

import com.coderising.rule01.jdbc.Connection;
import com.coderising.rule01.jdbc.DriverManager;

public class DriverManagerTest {

	public static void main(String[] args) throws Exception{
		Class.forName("com.coderising.rule01.jdbc.mysql.MySqlDriver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/testdb", 
				"root", "");
		System.out.println(conn);
		
		Class.forName("com.coderising.rule01.jdbc.oracle.OracleDriver");
		//DriverManager.getConnection("jdbc:oracle....", userName, password)
	}

}
