package com.coderising.rule03;

public class ApplicationConfig {
	
	public ApplicationConfig(){
		
	};
	
	public void doSomething(){
		//////
	}
	
	
}
