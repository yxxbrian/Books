package com.coderising.rule03;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ApplicationConfigTest {
	public static void main(String[] args) throws Exception {
		File f = new File("appconfig");
		ApplicationConfig config = new ApplicationConfig();
		writeToFile(f,config);
		
		
		ApplicationConfig config1 = readFromFile(f);
		ApplicationConfig config2 = readFromFile(f);
		System.out.println(config1);		
		System.out.println(config2);
	}
	
	public static void writeToFile(File f, ApplicationConfig config) throws Exception{
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));

		oos.writeObject(config);
		oos.close();
	}
	public static ApplicationConfig readFromFile(File f) throws Exception {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
		ApplicationConfig config = (ApplicationConfig) ois.readObject();
		ois.close();
		return config;
	}
}
