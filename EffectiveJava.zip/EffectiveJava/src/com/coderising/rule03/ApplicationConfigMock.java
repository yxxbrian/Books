package com.coderising.rule03;

public class ApplicationConfigMock extends ApplicationConfig {
	
}
