package com.coderising.rule03;

public class OrderService {
	ApplicationConfig config ;
	public void createOrder(String name){
		
	
		
	}
	public void setApplicationConfig(ApplicationConfig config){
		this.config = config;
	}
}
