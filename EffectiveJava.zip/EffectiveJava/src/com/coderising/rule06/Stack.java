package com.coderising.rule06;

import java.util.Arrays;

public class Stack {
	
	private Object[] elements;
	private int size = 0;
	private static final int DEFAULT_INITIAL_CAPACITY = 5;
	
	
	public Stack(){
		elements = new Object[DEFAULT_INITIAL_CAPACITY];
	}
	
	public void  push(Object e){
		ensureCapacity();
		elements[size] = e;
		size ++;
	}
	private void ensureCapacity() {
		if(elements.length == size){
			elements = Arrays.copyOf(elements, 2*size+1);
			System.gc();
		}		
	}
	
	public Object pop(){
		if(size == 0){
			throw new RuntimeException();
		}
		Object e = elements[size];
		elements[size] = null;
		size --;
		return e;
	}

	public static void main(String[] args) {
		Stack s = new Stack();
		s.push("0");
		s.push("1");
		s.push("2");
		s.push("3");
		s.push("4");
		s.push("5");
		s.push("6");
		s.pop();
		s.pop();
	}

}
