package com.coderising.rule02;

public class PersonV1
{
   private  final String lastName;  // 必填
   private  final String firstName; // 必填  
   
   private  final String city;      //选填
   private  final String address;   //选填
   private  final boolean isMale;   //选填
   
   
   public PersonV1(String firstName, String lastName) {	
	   this(firstName,lastName,null,null,false);
   }

	public PersonV1(String firstName,String lastName,  String city) {
		this(firstName,lastName,city,null,false);
	}

	public PersonV1(String firstName, String lastName,  String city, String address) {
		
		this(firstName,lastName,city,address,false);
	}
	
	public PersonV1(String firstName, String lastName,  String city, String address,boolean isMale) {
		
		this.lastName = lastName;
		this.firstName = firstName;
		this.city = city;
		this.address = address;
		this.isMale = isMale;
	}
   
	public static void main(String[] args) {
		new PersonV1("liu","xin");
		new PersonV1("liu","xin","beijing");
		new PersonV1("liu","xin","beijing","softwarepark");
		new PersonV1("liu","xin","beijing","softwarepark", true);
	}
 
}