package com.coderising.rule02;

public class Person {
	private  final String firstName; // 必填  
	private  final String lastName;  // 必填
	
	   
	private  final String city;      //选填
	private  final String address;   //选填
	private  final boolean isMale;   //选填
	
	public static class Builder{
		private  String firstName; // 必填  
		private  String lastName;  // 必填
		
		private  String city = null;      //选填
		private  String address = null;   //选填
		private  boolean isMale = true;   //选填
		
		public Builder(String firstName,String lastName){
			this.firstName = firstName;
			this.lastName = lastName;
		}
		public Builder city(String city){
			this.city = city;
			return this;
		}
		public Builder address(String address){
			this.address = address;
			return this;
		}
		public Builder isMale(boolean isMale){
			this.isMale = isMale;
			return this;
		}
		public Person build(){
			return new Person(this);
		}
	}
	
	private Person(Builder builder){
		this.firstName = builder.firstName;
		this.lastName = builder.lastName;
		this.city = builder.city;
		this.address = builder.address;
		this.isMale = builder.isMale;
		// 执行参数检查， 如果不合法，拋出exception
		//throw new java.lang.IllegalArgumentException();
	}
	
	public static void main(String[] args) {
		Person p1 = new Person.Builder("liu", "xin")
				.city("beijing")
				.address("software park")
				.isMale(true)
				.build();
		
		Person p2 = new Person.Builder("liu", "xin")
				.isMale(true)
				.address("xierqi")
				.city("beijing")
				.build();	
		
		

	}

}
