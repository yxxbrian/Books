package com.coderising.rule02;

public class PersonV2 {
	private   String lastName;  // 必填
	private   String firstName; // 必填  
   
	private  String city;      //选填
	private  String address;   //选填
	private  boolean isMale;   //选填
	
	public PersonV2(){		
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setCity(String city) {
		//判断address 和city 的关系是否合法
		this.city = city;
	}

	public void setAddress(String address) {
		//判断address 和city 的关系是否合法
		this.address = address;
	}

	public void setMale(boolean isMale) {
		this.isMale = isMale;
	}
	
	public static void main(String[] args) {
		PersonV2 p = new PersonV2();
		p.setFirstName("liu");
		p.setLastName("xin");
		
		p.setAddress("software park");
		p.setCity("beijing");
		p.setMale(true);
	}
}
