package com.coderising.rule04;

public  abstract class StringTool {
	public static void trim(String s){
		
	}
}
