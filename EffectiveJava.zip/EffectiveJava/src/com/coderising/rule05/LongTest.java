package com.coderising.rule05;

public class LongTest {
	public static void main(String[] args) {
		
		long sum = 0L;
		
		long start = System.currentTimeMillis();
		
		for (int i=0; i<Integer.MAX_VALUE; i++){
			sum += i;
		}
		
		long end = System.currentTimeMillis();
		
		System.out.println(sum+"  ,time is "+(end-start));
	}
}
