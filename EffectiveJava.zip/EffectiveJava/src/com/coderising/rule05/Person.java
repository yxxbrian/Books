package com.coderising.rule05;

import java.util.Calendar;
import java.util.Date;

import java.util.TimeZone;

public class Person {
	private static Calendar gmtCal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));	
	private static Date start;
	private static Date end;
	
	private Date birthDate;
	
	static{
		gmtCal.set(1946, Calendar.JANUARY,1,0,0,0);		
		start = gmtCal.getTime();
		
		gmtCal.set(1965, Calendar.JANUARY,1,0,0,0);
		end = gmtCal.getTime();
	}
	
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public boolean isBabyBoomer(){		
		
		return this.birthDate.compareTo(start) >=0  &&
				this.birthDate.compareTo(end) <0;
		
	}
}
